import Foundation

var aa = 0
aa += 10
aa = a + 10

    // Логические операторы
    // и
true && true //true
true && false // false
false && true // false
false && false // false


    // ИЛИ

true || true 
true || false
false || true //true
false || false //false

    //не

    !true // false
        !false //true

let r = 5
let t = 8

(t > r) || (t == 7) //true

    //если

if t == 6 {
    print("r")
} else if t == 7 {
    print ("t")
}else {
    print("NOOOO")
}

//тернарный оператор

(t == 5) && (t == 6) ? print("r") : print("t")

var h = 100
var isH = false

let rrr = h + (isH ? 20 : 10)

print(rrr)

    //switch

let userMark = 4

switch userMark {

case 1,2: 
    print("Экзамен не сдан")
    
    case 3 :
        print("Экзамен сдан на 3")
        case 4:
            print("Хорошо")
default:
    print("Студент не пришел")
}


let level: Character = "А"

switch level {

case "А":
    print("Все не ок")
    fallthrough
    case "Б":
        print("Средне")
        case "С":
            print("Все ок")
default:
    break
}


//where

var a = 10
var b = 5
var c = 13

var D = (b*b) - 4 * a * c
switch D {
case _ where D > 0:
print("2")
case _ where D == 0:
    print("1")
default:
    print("NOO")
}

//Циклы

//For in
var totalSum = 0

for i in 1...10 {
    totalSum += i
} 

print(totalSum)

var musicArray = ["Rock", "Classical", "Hip"]

for musicName in musicArray {
    print("I love \(musicName)")
}

var country = ["Россия":"ЕАЭС", "США":"НАТО", "Франция":"ЕС"]

for (countryName, blockName) in country {
    print("\(countryName) в блоке \(blockName)")
}

//while 

var w = 1
var resultS = 0

while w <= 10 {
    resultS += w
    w += 1
}
print("resultS \(resultS)")
print(w)


    //repeat while

var o = 1
var result = 0

repeat {
    result += o
    o += 1
} while o <= 10

print(result)


    // функция

func myFirstFunction(firstValue someValue: Int, another: String, _ value: String )-> String {
    let c: String = String(someValue) + another + value 
    return c 
}

myFirstFunction(firstValue: 5, another: "Hello", "world")

func find(element a: Int, in array: [Int]){
    array
}

find(element: 5, in: [1,2,3,5])

func printMessage() -> (){
    print("Hello world")
}

printMessage()

func changeValues(_ a: inout Int, _ b: inout Int) -> (){
    let tmp = a
    a = b
    b = tmp
}

var y = 10
var p = 5 
print(y)
print(p)
changeValues(&y, &p)
print(y)
print(p)

func generate(code: Int, message: String) -> String {
    let returnMessage = "Получение сообщения \(message) с кодом \(code)"
    return returnMessage
}

print(generate(code: 200, message: "Ошибка"))
